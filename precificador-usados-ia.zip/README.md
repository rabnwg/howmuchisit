# Precificador Usados IA

Este projeto permite sugerir preços ideais para produtos usados com base em descrição e scraping de marketplaces.

## Como usar

1. Configure a variável `OPENAI_API_KEY` em `.env`
2. Rode o projeto com `npm run dev`
3. Acesse a interface e preencha as informações do produto
